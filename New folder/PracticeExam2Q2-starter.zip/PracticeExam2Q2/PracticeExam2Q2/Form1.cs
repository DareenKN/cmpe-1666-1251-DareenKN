﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PracticeExam2Q2
{
    public partial class Form1 : Form
    { 
         List<int> searchList = new List<int>() {23,24,45,54,59,67,92,95,102,105,110 };
        //You can include any required class-level variable declaration here
        
        public Form1()
        {
            InitializeComponent();
        }


      //Write your code here
       

    }
    }

